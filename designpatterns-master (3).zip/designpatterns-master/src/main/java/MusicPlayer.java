public interface MusicPlayer {
    void playMusic(String audioType, String fileName);
}
