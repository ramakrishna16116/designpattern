# Refactoring Design Patterns

Refactor code and build with Gradle or Mavel
Use Jenkins to continuously build and test your changes.
